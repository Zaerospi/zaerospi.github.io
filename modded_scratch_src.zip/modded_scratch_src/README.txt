These actionscript source code files are for you Scratch modders(or
possibly developers) that are interested in the source code for my
mod that adds a block to set one list to another list.

    [set [ v] to [ v] :: list]

Summary of Changes

-In Specs.as, I added:
	// lists
	["set %m.list to %m.list",				" ", 12, "setList:toList:"],
                ["set %m.list to %s",                                   " ", 12, "setList:toString:"],
	["-"],
	/* ... */

-In primitives/ListPrims.as I added:
	//public function addPrimsTo(primTable:Dictionary):void {
		//primTable[Specs.GET_LIST]	= primContents;
		primTable['setList:toList:']	= primSetToList;
                primTable['setList:toString:']  = primSetToString;
	/* ... */

	private function primSetToList(b:Block):void {
		var list:ListWatcher = listarg(b, 0);
		if(!list) return;
		var newContents:Array = list.contents;
		list = listarg(b, 1);
		if(!list) return;
		listSet(list, newContents);
		if (list.visible) list.updateWatcher(list.contents.length, false, interp);
	}

        private function primSetToString(b:Block):void {
                var list:ListWatcher = listarg(b, 0);
                if(!list) return;
                var s:String = interp.arg(b, 1);
                var newContents:Array = s.split(" ");
                list.importLines(newContents);
        }

-In watcher/ListWatch.as, I changed importLines public instead of private, in order to allow primitives/ListPrims.as to access it, which is probably not the best way to go about this.